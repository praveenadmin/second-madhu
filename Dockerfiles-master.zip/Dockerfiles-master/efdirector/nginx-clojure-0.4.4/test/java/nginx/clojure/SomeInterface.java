/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package nginx.clojure;

/**
 * A dummy interface used for the InterfaceTest
 * 
 * @author Elias Naur
 */
public interface SomeInterface {
    
    void doStuff() throws SuspendExecution;
    
}
