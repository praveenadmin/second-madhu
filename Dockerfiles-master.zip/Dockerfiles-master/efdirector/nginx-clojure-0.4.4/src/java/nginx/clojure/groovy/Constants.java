package nginx.clojure.groovy;

public class Constants extends nginx.clojure.java.Constants {

}
