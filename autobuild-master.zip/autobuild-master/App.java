public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World .. JMS technologies." );
    }

	public int calculateSomething() {
		return 0;
	}
}
