#### A test Flask app

[![Build Status](https://travis-ci.org/rn4ir/flask-gunicorn-demo.svg?branch=master)](https://travis-ci.org/rn4ir/flask-gunicorn-demo)  
  
Yet another test Flask app:  
- to test CI with Travis-CI    
- to test CI/CD with Jenkins  
- *wip*
