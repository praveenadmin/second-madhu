#!/usr/bin/env python

# ~/config.py

# Enable Flask's debugging features. Should be False in production
DEBUG = True
