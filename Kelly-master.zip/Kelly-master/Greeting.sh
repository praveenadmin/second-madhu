#!/bin/bash
echo "hello"
echo "Happy new year 2019 welcome"
ls -ltr
echo "Happy new year 2019"
